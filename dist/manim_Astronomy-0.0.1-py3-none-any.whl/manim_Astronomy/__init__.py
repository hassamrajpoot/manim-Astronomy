from stellar_objects import *

__all__ = ['Star','SpaceTimeFabric']